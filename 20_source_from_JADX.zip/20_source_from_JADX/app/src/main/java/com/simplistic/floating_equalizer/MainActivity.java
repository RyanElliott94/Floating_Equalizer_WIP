/*
 * Decompiled with CFR 0_58.
 * 
 * Could not load the following classes:
 *  android.app.Dialog
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.media.MediaPlayer
 *  android.media.MediaPlayer$OnCompletionListener
 *  android.os.Bundle
 *  android.preference.PreferenceManager
 *  android.support.v4.app.Fragment
 *  android.support.v4.app.FragmentActivity
 *  android.support.v4.app.FragmentManager
 *  android.support.v4.view.ViewPager
 *  android.view.Menu
 *  android.view.MenuInflater
 *  android.view.MenuItem
 *  android.view.View
 *  android.widget.TabHost
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 */
package com.simplistic.floating_equalizer;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TabHost;

import androidx.appcompat.app.AlertDialog;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager.widget.ViewPager;

import com.simplistic.floating_equalizer.model.EqualizerApi;
import com.simplistic.floating_equalizer.model.Profile;
import com.simplistic.floating_equalizer.model.lib.DbHelper;
import com.simplistic.floating_equalizer.service.EqualizerService;
import com.simplistic.floating_equalizer.service.Floating;
import com.simplistic.floating_equalizer.ui.EffectsFragment;
import com.simplistic.floating_equalizer.ui.EqualizerFragment;
import com.simplistic.floating_equalizer.ui.ProfileFragment;
import com.simplistic.floating_equalizer.ui.lib.EqualizerProfile;
import com.simplistic.floating_equalizer.ui.lib.TabPagerAdapter;

import java.util.List;


public class MainActivity extends FragmentActivity implements
		EqualizerProfile.EqualizerProfileHandler {
	
	protected static String EQUALIZER_TAB_TAG;
	private static String PROFILE_TAB_TAG;
	private static String EFFECT_TAB_TAG;
	protected EffectsFragment mEffect;
	protected EqualizerFragment mEqualizer;
    EqualizerService service;
	protected MenuItem mPlayButton;
	protected MediaPlayer mPlayer;
	protected ProfileFragment mProfile;
	protected Intent mServiceIntent;
	protected MenuItem mStopButton;
	protected TabHost mTabHost;
	protected TabPagerAdapter mTabPagerAdapter;
	protected ViewPager mViewPager;
    Floating floating;
	private Button min;
	private Button close;
	private NotificationUtils mNotificationUtils;

	static {
		MainActivity.EQUALIZER_TAB_TAG = "equalizer";
		MainActivity.PROFILE_TAB_TAG = "profile";
		MainActivity.EFFECT_TAB_TAG = "effect";
	}

	

	protected Fragment instantiateFragment(Class<?> class_, Bundle bundle) {
		return Fragment.instantiate((this), (class_.getName()), (bundle));
	}

	@Override
	public void onBeforeSelectProfile() {
	}

	
	
	@Override
	public void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		this.setContentView(R.layout.main);

		mNotificationUtils = new NotificationUtils(this);

		min = findViewById(R.id.collapse);
		close = findViewById(R.id.close);
		
		this.mViewPager = findViewById(R.id.pager);
		this.mTabHost = findViewById(android.R.id.tabhost);
		this.mTabHost.setup();
		this.mTabPagerAdapter = new TabPagerAdapter((this), this.mTabHost,
				this.mViewPager);
		if (bundle != null) {
			this.mEqualizer = (EqualizerFragment) this
					.getSupportFragmentManager().getFragment(bundle,
					MainActivity.EQUALIZER_TAB_TAG);
			mProfile = (ProfileFragment) getSupportFragmentManager().getFragment(bundle, PROFILE_TAB_TAG);
			
		}
		if (this.mEqualizer == null) {
			this.mEqualizer = (EqualizerFragment) this.instantiateFragment(
					EqualizerFragment.class, bundle);
		}
		if (this.mEffect == null) {
			this.mEffect = (EffectsFragment) this.instantiateFragment(
					EffectsFragment.class, bundle);
		}
		if (this.mProfile == null) {
			this.mProfile = (ProfileFragment) this.instantiateFragment(
					ProfileFragment.class, bundle);
		}
		
		mProfile.setOnSelectProfileHanlder(this);
		
		mTabPagerAdapter.addTab(MainActivity.EQUALIZER_TAB_TAG,
				"Equalizer", mEqualizer);
		
		mTabPagerAdapter.addTab(PROFILE_TAB_TAG, "Presets", mProfile);
		
		mTabPagerAdapter.addTab(EFFECT_TAB_TAG, "Extra's", mEffect);
		
		EqualizerApi.init(0);
        new Profile(this).loadSettings();
        Intent i = new Intent(MainActivity.this, EqualizerService.class);
		startService(i);
		SharedPreferences.Editor editor = PreferenceManager
				.getDefaultSharedPreferences(this).edit();
		editor.putBoolean(EqualizerApi.PREF_AUTOSTART, true);
		editor.apply();
		
		min.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				saveBands();
				finish();
			}
			
		});
		
		close.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				saveBands();
				closeAll();
				finish();
			}
			
		});
	}
	
	public void saveBands(){
		new Profile(this).saveSettings();
	}
	
	public void closeCursor(){
		DbHelper.getInstance(this).close();
	}
	
	
	public void closeAll(){
		EqualizerApi.destroy();
		DbHelper.getInstance(this).closeAdapter();
		Intent i = new Intent(getApplicationContext(), EqualizerService.class);
		stopService(i);
	}
	
	public void Choose() {
	    AlertDialog.Builder builder = new AlertDialog.Builder((this));
	    builder.setTitle("Please Choose:");
	    builder.setMessage("Notification: This will place a notification at thed top of the phone"
	    		+ "\n"
	    		+ "\n"
	    		+ "Floating: This will place floating button which can be used as a shortcut back the EQ "
	    		+ "\n"
	    		+ "\n"
	    		+ "Close EQ: This will permanently close the Equalizer");
	    builder.setCancelable(true);
	    builder.setIcon(R.drawable.ic_launcher_app);
	    builder.setNegativeButton("Close EQ", new OnClickListener(){

	        @Override
			public void onClick(DialogInterface dialogInterface2, int dialogInterface) {
	        	EqualizerApi.destroy();
				NotificationCompat.Builder nb = mNotificationUtils.
						getAndroidChannelNotification("Floating Equalizer", "");

				mNotificationUtils.getManager().notify(101, nb.build());
	        	finish();
	       }
	    });
	    
	    builder.setNeutralButton("Keep Running", new OnClickListener(){

	        @Override
			public void onClick(DialogInterface dialogInterface2, int dialogInterface) {
				NotificationCompat.Builder nb = mNotificationUtils.
						getAndroidChannelNotification("Floating Equalizer", "");

				mNotificationUtils.getManager().notify(101, nb.build());
	        	finish();
	    	}
	    });
	    builder.setPositiveButton("Stop Notification", new OnClickListener(){

	        @Override
			public void onClick(DialogInterface dialogInterface2, int dialogInterface) {
				NotificationCompat.Builder nb = mNotificationUtils.
						getAndroidChannelNotification("Floating Equalizer", "");

				mNotificationUtils.getManager().cancelAll();
	        }

			
	    });
	    builder.create().show();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	
	
	
	@Override
	public boolean onOptionsItemSelected(MenuItem menuItem) {
		if (menuItem.getItemId() == R.id.add_profile) {
			mProfile.manageProfile(this, null);
		}
		if (menuItem.getItemId() == R.id.rate) {
			try {
			    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.simplistic.floatingequalizerpro")));
			} catch (android.content.ActivityNotFoundException anfe) {
			    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=com.simplistic.floatingequalizerpro")));
			}
        	}
		return super.onOptionsItemSelected(menuItem);
	}

	@Override
	protected void onSaveInstanceState(Bundle bundle) {
		super.onSaveInstanceState(bundle);
		try {
			this.getSupportFragmentManager().putFragment(bundle,
					EQUALIZER_TAB_TAG, mEqualizer);
			
			return;
		} catch (Exception e) {
			return;
		}
	}

	@Override
	public void onSelectProfile() {
		try {
			if (mEqualizer.isVisible()) {
				mEqualizer.refetch();
			}
			if (mEffect.isVisible()) {
				mEffect.refetch();
			}
			
			return;
		} catch (Exception e) {
			return;
		}
	}

	public boolean isNotificationRunning(String serviceClassName){
	        final ActivityManager activityManager = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
	        final List<RunningServiceInfo> services = activityManager.getRunningServices(Integer.MAX_VALUE);

	        for (RunningServiceInfo runningServiceInfo : services) {
	            if (runningServiceInfo.service.getClassName().equals(serviceClassName)){
	            	Intent i = new Intent(getApplicationContext(), EqualizerService.class);
	        		stopService(i);
	                return true;
	            }
	            Intent i = new Intent(getApplicationContext(), Floating.class);
	    		startService(i);
	        }
	        return false;
	     }
	    
	    public boolean closeNotificationIfRunning(String serviceClassName){
	        final ActivityManager activityManager = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
	        final List<RunningServiceInfo> services = activityManager.getRunningServices(Integer.MAX_VALUE);

	        for (RunningServiceInfo runningServiceInfo : services) {
	            if (runningServiceInfo.service.getClassName().equals(serviceClassName)){
	            	return true;
	            }
	            Intent i = new Intent(getApplicationContext(), EqualizerService.class);
        		stopService(i);
        		EqualizerApi.destroy();
        		new Profile(this).saveSettings();
	        }
	        return false;
	     }
	
	
	    public boolean isFloatingRunning(String serviceClassName){
	        final ActivityManager activityManager = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
	        final List<RunningServiceInfo> services = activityManager.getRunningServices(Integer.MAX_VALUE);

	        for (RunningServiceInfo runningServiceInfo : services) {
	            if (runningServiceInfo.service.getClassName().equals(serviceClassName)){
	            	Intent i = new Intent(getApplicationContext(), Floating.class);
	        		stopService(i);
	                return true;
	            }
	            Intent i = new Intent(getApplicationContext(), EqualizerService.class);
	    		startService(i);
	        }
	        return false;
	     }

	    public boolean closeFloatingIfRunning(String serviceClassName){
	        final ActivityManager activityManager = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
	        final List<RunningServiceInfo> services = activityManager.getRunningServices(Integer.MAX_VALUE);

	        for (RunningServiceInfo runningServiceInfo : services) {
	            if (runningServiceInfo.service.getClassName().equals(serviceClassName)){
	            	return true;
	            }
	            Intent i = new Intent(getApplicationContext(), Floating.class);
        		stopService(i);
        		EqualizerApi.destroy();
        		new Profile(this).saveSettings();
	        }
	        return false;
	     }



}
