package com.simplistic.floating_equalizer.service;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import com.simplistic.floating_equalizer.EqualizerActivity;
import com.simplistic.floating_equalizer.FloatingEQ;
import com.simplistic.floating_equalizer.R;

public class Floating extends Service {

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	ImageView chatHead;
    WindowManager windowManager;
	private EqualizerActivity mainEQ;

  

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     */
    public void onCreate() {
        super.onCreate();
        
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        chatHead = new ImageView(this);
        chatHead.setImageResource(R.drawable.ic_launcher);
        final WindowManager.LayoutParams params = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        params.gravity = 51;
        params.x = 0;
        params.y = 100;
        windowManager.addView(chatHead, params);
       
        chatHead.setOnTouchListener(new View.OnTouchListener() {
	    	  private int initialX;
	    	  private int initialY;
	    	  private float initialTouchX;
	    	  private float initialTouchY;

	    	  @Override 
	    	  public boolean onTouch(View v, MotionEvent event) {
	    		    switch (event.getAction()) {
	    		      case MotionEvent.ACTION_DOWN:
	    		        initialX = params.x;
	    		        initialY = params.y;
	    		        initialTouchX = event.getRawX();
	    		        initialTouchY = event.getRawY();
	    		        return false;
	    		      case MotionEvent.ACTION_UP:
	    		        return false;
	    		      case MotionEvent.ACTION_MOVE:
	    		        params.x = initialX + (int) (event.getRawX() - initialTouchX);
	    		        params.y = initialY + (int) (event.getRawY() - initialTouchY);
	    		        windowManager.updateViewLayout(chatHead, params);
	    		        return false;
	    		    }
	    		    return false;
	    		  }
	    		});
	    
      
        chatHead.setOnLongClickListener(new View.OnLongClickListener(){

            public boolean onLongClick(View view) {
            	Intent intent = new Intent(getApplicationContext(), FloatingEQ.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                return false;
            }
        });
    }
    
   public void removeButton(){
	   if (chatHead != null) {
           windowManager.removeView(chatHead);
	   }
       
   }
   
    public void onDestroy() {
        super.onDestroy();
        if (chatHead != null) {
            windowManager.removeView(chatHead);
           
        }
        stopForeground(true);
    }

}
