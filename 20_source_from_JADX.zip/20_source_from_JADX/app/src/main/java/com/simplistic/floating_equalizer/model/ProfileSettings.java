/*
 * Decompiled with CFR 0_58.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.simplistic.floating_equalizer.model;

public class ProfileSettings {
	public static final String BASS_BOOST = "bass_boost";
	public static final String BASS_BOOST_ENABLED = "bass_boost_enabled";
	public static final String EQUALIZER_ENABLED = "equalizer_enabled";
	public static final String EQUALIZER_PREFIX = "equalizer_band_";
	public static final String REVERBERATION = "reverberation";
	public static final String VIRTUALIZER = "virtualizer";
	public static final String VIRTUALIZER_ENABLED = "virtualizer_enabled";
}
