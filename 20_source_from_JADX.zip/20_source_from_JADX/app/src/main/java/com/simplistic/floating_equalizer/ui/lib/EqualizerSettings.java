/*
 * Decompiled with CFR 0_58.
 * 
 * Could not load the following classes:
 *  android.support.v4.app.Fragment
 */
package com.simplistic.floating_equalizer.ui.lib;

import androidx.fragment.app.Fragment;

public abstract class EqualizerSettings extends Fragment {
	public abstract void refetch();
}
