/*
 * Decompiled with CFR 0_58.
 * 
 * Could not load the following classes:
 *  android.app.AlertDialog
 *  android.app.AlertDialog$Builder
 *  android.app.Dialog
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.text.Editable
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.widget.EditText
 *  java.lang.CharSequence
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 */
package com.simplistic.floating_equalizer.ui;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

public class ProfileDialog {
	public interface OnProfileUpdate {
		public void onProfileUpdate(String var1, Long var2);
	}
	public static final int PROFILE_MANAGEMENT_DIALOG = 1000;
	protected Context mContext;
	protected EditText mEdit;

	protected OnProfileUpdate mHandler;

	public ProfileDialog(Context context) {
		mContext = context;
	}

	public void setOnProfileUpdateHandler(OnProfileUpdate onProfileUpdate) {
		mHandler = onProfileUpdate;
	}

	public void setProfileName(String string) {
		if (mEdit == null)
			return;
		mEdit.setText((string));
	}

	/*
	 * Enabled aggressive block sorting Enabled unnecessary exception pruning
	 */
	@SuppressLint("ResourceType")
	public Dialog showManagementDialog(final Long long_) {
		AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
		View view = ((LayoutInflater) mContext
				.getSystemService(Messages.getString("ProfileDialog.0"))).inflate(2130903047, //$NON-NLS-1$
						(ViewGroup) (null));
		builder.setView(view);
		mEdit = (EditText) (view.findViewById(2131165200));
		if (long_ != null) {
			builder.setTitle(2130968597);
		} else {
			builder.setTitle(2130968595);
		}
		builder.setNegativeButton(17039360,
				(new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialogInterface2,
							int dialogInterface) {
					}
				}));
		builder.setPositiveButton(17039370,
				(new DialogInterface.OnClickListener() {

					@Override
					public void onClick(DialogInterface dialogInterface,
							int dialogInterface2) {
						if (mHandler == null)
							return;
						mHandler.onProfileUpdate(mEdit.getText().toString(),
								long_);
					}
				}));
		return builder.show();
	}

}
